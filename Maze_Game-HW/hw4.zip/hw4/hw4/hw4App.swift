//
//  hw4App.swift
//  hw4
//
//  Created by Andy Huang on 3/2/23.
//

import SwiftUI

@main
struct hw4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
